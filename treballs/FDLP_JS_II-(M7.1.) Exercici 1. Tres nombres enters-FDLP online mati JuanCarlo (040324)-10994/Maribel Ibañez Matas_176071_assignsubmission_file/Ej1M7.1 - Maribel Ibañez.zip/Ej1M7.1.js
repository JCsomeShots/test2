'use strict';

function mostrar() { 
    const num1 = parseInt(document.getElementById('num1').value);
    const num2 = parseInt(document.getElementById('num2').value);
    const num3 = parseInt(document.getElementById('num3').value);
    const arr = [num1, num2, num3];
    let numeroMasGrande = -Infinity;
    let numeroMasPequeno = Infinity;
    let result = document.getElementById('result');

    // Buscar el número más grande y el número más pequeño
    for (const numero of arr) {
        if (numero > numeroMasGrande) {
            numeroMasGrande = numero;
        }
        if (numero < numeroMasPequeno) {
            numeroMasPequeno = numero;
        }
    }

    // Contar cuántas veces se repite cada número en el array
    const contador = {};
    for (const numero of arr) {
        contador[numero] = (contador[numero] || 0) + 1;
    }

    //Buscar números iguales
    let numerosIguales = [];
    for (const numero in contador) {
        if (contador[numero] >= 2) {
            numerosIguales.push(numero);
        }
    }

    // Mostrar
    if (numerosIguales.length === 0) {
        result.innerHTML = `El número más grande es el: ${numeroMasGrande}<br>El número más pequeño es el: ${numeroMasPequeno}`;
    } else {
        result.innerHTML = `El número ${numerosIguales.join(', ')} se repite.`;
    }
}

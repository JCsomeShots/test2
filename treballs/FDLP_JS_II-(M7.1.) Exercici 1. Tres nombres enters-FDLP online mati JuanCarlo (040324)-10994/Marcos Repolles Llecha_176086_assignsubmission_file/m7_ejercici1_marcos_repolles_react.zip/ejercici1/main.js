'use strict'


let divresult = document.getElementById("result");
const array = [];
const duplicat = [];
let numero = 0;
let i = 0;


for(i=0; i < 3; i++){

    numero = parseInt(prompt("Introduixi tres nombres enters: "));
    array.push(numero);  // guardar numeros en array

}

array.sort(); //ordenar array

for(i=0; i < array.length; i++){

    if(array[i] == array[i+1]){ // si son iguales es duplicado

        duplicat.push(array[i])
    }

}


divresult.innerHTML = `El major numero es ${(Math.max(...array))}, el menor numero es ${(Math.min(...array))}`; 

if(duplicat.length != 0) // si se guardo un duplicado entonces el condicional es true
{

    divresult.innerHTML += `<br><br> Hi ha 2 numeros iguals:  ${duplicat[0]}`;  // para evitar que si pones 3 3 3 salga 3 3

}



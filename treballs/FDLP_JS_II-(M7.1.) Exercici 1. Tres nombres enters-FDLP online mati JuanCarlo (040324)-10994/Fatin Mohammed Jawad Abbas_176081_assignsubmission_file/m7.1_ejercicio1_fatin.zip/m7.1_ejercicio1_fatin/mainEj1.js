"use strict";

const result = document.getElementById('result');

 function analizar(){
    let num1 = parseInt( document.getElementById('num1').value);
    let num2 = parseInt (document.getElementById('num2').value);
    let num3 = parseInt (document.getElementById('num3').value);
    
    //comprobar cual es el mayor
    let mayor = num1;
    if ( num2 > mayor ){
        mayor = num2;
    }
    if (num3 > mayor ){
        mayor = num3;
    }

    //comprbar cual es el menor
    let menor = num1;
    if (num2 < menor) {
        menor = num2;
    }
    if (num3 < menor){
        menor = num3
    }

    // comprobar si son iguales
    let igual = 'No hay números iguales.'
    if (num1 == num2 && num1 == num3){
           
                igual ='los tres numeros es igual'
            }else {
                if (num1 == num2 || num1 ==num3 || num2 == num3) {
                    igual ='Hay dos numeros iguales'
                }
            }
        
   //imprimir el resultado
    result.innerHTML = `El numero mayor es ${mayor} <br> 
                        El numero menor es ${menor} <br>
                        ${igual}`
} 








'use strict'

const arrayNombres = []
const result = document.getElementById('result');

function mostrar() { //captura

    let num1 = parseInt(document.getElementById('num1').value);
    const imprimir = document.getElementById('imprimir'); // DIV

    imprimir.innerHTML = '' //limpieza

    for (let i = 0; i < num1; i++) { // Crea inputs
        
        let inputCreado = document.createElement('input')
            inputCreado.type = 'text'
            inputCreado.className = 'nombres'
            inputCreado.placeholder = 'Introduce un nombre'
       
        let br = document.createElement('br')
      
        imprimir.appendChild(inputCreado)
        imprimir.appendChild(br)
    }

    imprimir.innerHTML += `<button type:"button" onclick= "capturarInput()"> Mostrar </button>`

}

function capturarInput() {

    let arrayNoms = document.querySelectorAll('.nombres') // Todas las coincidencias y las almacena en un array

    for (let i = 0; i < arrayNoms.length; i++) {
        console.log(arrayNoms[0].value)

        let nom = arrayNoms[i].value
        arrayNoms[0].value = ''

        if (nom.charAt(0).toUpperCase() == 'A' ){
            arrayNombres.push(nom)
        }

    }

    imprimir()
}

function imprimir(){

    if (arrayNombres.length > 0 ) {
    result.innerHTML = `Los nombres más bonitos son: <br> ${arrayNombres.join('<br>')}`
    } else {
        result.innerHTML = `No has introducido ningún nombre bonito`
    }
}
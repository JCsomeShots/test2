'use stric'

function escribirNombres(numeroNino, arr){
   
    for (let i = 0; i < numeroNino; i++){
        let nombre = prompt( `Escribe el nomre ${i + 1}`).toLocaleUpperCase();
      arr.push(nombre);
    }
    return  buscarNombreConA(arr)
}
    

function buscarNombreConA(arr2){
    let arrNombresConA = [];
    
    for (let i = 0; i < arr2.length ; i++){
        if (arr2[i].charAt(0).toLocaleUpperCase() == 'A'){
            arrNombresConA.push(arr2[i]);
            console.log(arr2[i]);
        }
    }
    if (arrNombresConA.length > 0) {
    return result.innerHTML = `Nombres con A: <br> ${arrNombresConA.join(', ')}`;   // Devuelve el array nombresConA
    } else {
        return result.innerHTML = `No hay nombres empiza con l aletra A` 
    }
}


function nombresConA(){
    let numeroNino = parseInt (document.getElementById('numeroNombre').value);
    let result = document.getElementById('result');
    let nombres = [];
   
    escribirNombres(numeroNino, nombres); //Llama a escribirNombres con dos parametro una variable y un array vacío 

}


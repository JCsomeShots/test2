'use strict'


function mostrarNoms(){

    let Numeronoms = ingresar();
    imprimir(comprobar(Numeronoms));

}

function ingresar(){

    let Numeronoms = parseInt(document.getElementById("text").value); // valor del component text

    return Numeronoms;


}

function comprobar(Numeronoms){

    const paraules = []; //array
    let text = ""; // mostrara les paraules que comencen amb la lletra A
    //let guardar = ""; // conte la primera lletra de la paraula en majuscula
    let k = 0;

    for(let i = 0; i < Numeronoms ; i++){ 

        k = i + 1; // aixi surt Posar el nom 1,2, etc
        let aux=prompt("Posar el nom " + k + ":"); 

        paraules.push(aux); // agrega paraules

        text += comparar(paraules[i]);

    
    }


    return text;


}

function comparar(paraules){

    let guardar = paraules.charAt(0).toUpperCase();
    let text = ""; 
    
        if(guardar == 'A'){

            text += paraules + " ";  // si es A la primera lletra guarda a la variable text
        }

    return text;

}

function imprimir (text){

    let divresult = document.getElementById('result');
    divresult.innerHTML = text;

}
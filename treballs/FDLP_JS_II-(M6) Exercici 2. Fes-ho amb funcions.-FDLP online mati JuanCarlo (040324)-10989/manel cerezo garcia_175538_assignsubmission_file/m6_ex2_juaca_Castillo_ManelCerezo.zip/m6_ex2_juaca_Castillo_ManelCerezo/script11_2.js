'use strict'
const arraNoms =[]
const result=document.getElementById('result');

function PedirNumero(){
    //captura variables
    let num =parseInt(document.getElementById('num1').value );
    const imprimir=document.getElementById('imprimir');
    

    //limpio el html cada vez que hago un click
    imprimir.innerHTML =''
    //
    for(let i=0; i<num; i++ ){
        //prompt('Nombre')
        let inputCREATE = document.createElement('input')
            inputCREATE.type ='text'
            inputCREATE.className='nombres'
            inputCREATE.placeholder='Escriba un nombre'
        
        let br = document.createElement('br')


        //imprimir.innerHTML= inputCREATE
        imprimir.appendChild(inputCREATE)
        imprimir.appendChild(br)
        imprimir.appendChild(br)
    }
    imprimir.innerHTML += `<button type="button" onclick="capturarInput()"> Click me</button>`



}

function capturarInput(){
    //vamos a capturar por la class
    let arrNoms = document.querySelectorAll('.nombres')

    //bucle para saber los nombres
    for (let i=0; i<arrNoms.length; i++){
        console.log(arrNoms[i].value)
        let nom =arrNoms[i].value
        arrNoms[i].value=''
        
        

        if (nom.charAt(0).toUpperCase() == 'A'){
            arraNoms.push(nom)

        }


    }
    imprimir()
}

function imprimir(){
    if (arraNoms.length>0){
        result.innerHTML =`Los nombres más bonitos son: ${arraNoms}`
    }else{
        result.innerHTML =`No has introducido nombres bonitos`

    }
}
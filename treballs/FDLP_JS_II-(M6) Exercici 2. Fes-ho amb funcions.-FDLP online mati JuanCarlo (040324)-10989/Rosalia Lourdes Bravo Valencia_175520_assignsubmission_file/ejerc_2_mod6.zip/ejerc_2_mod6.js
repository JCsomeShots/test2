'use strict'
/*Alumna "Rosalia Bravo Valencia"*
 *******(M6) Exercicio 2. functions*******
 *******Solicite al usuario cuántos nombres desea introducir***
 
*/
   
  function cancelar(){
    window.location.reload();
  }

  function numberNames(){
    let numNoms = parseInt(document.getElementById("numNoms").value);
    return numNoms;
  }

  function addNames(numNoms){
    
    const nomsArr = [];
    for (let i = 0; i < numNoms; i++){
      let nom = prompt("Introduce un nombre" + ( i + 1 ) + ":" );
      nomsArr.push(nom);
    }
    return nomsArr;
  }
  
  function selectNames(){
    let result = document.getElementById('result')
    let noms = addNames(numberNames()); // Obtener los nombres
    let message = "Los nombres que inician con la letra A son: <br>"; 
    for (let j = 0; j < noms.length; j++){
      let firstLetters = noms[j].charAt(0).toUpperCase();
      let restLetters = noms[j].slice(1);
      if (firstLetters === 'A'){
        noms[j] = firstLetters + restLetters;
        message  += noms[j] + '<br>';
        console.log( "\n" + noms[j]);
      }
    }
    document.getElementById("result").innerHTML= message;
  }
 
 
'use strict'

//Global
const ArrayNoms = []
const resultDiv = document.getElementById('result')

//1. Funció de "Continua"
function filtrarnoms(){

    //Captura
    let quantitatNoms = parseInt(document.getElementById('quantitatNoms').value)
    const imprimirDiv = document.getElementById('imprimir')
    
    //Per a que es reiniciï al posar un input diferent
    imprimirDiv.innerHTML = ''

    //Bucle per insertar els noms que volem introduir
    for (let i = 0; i < quantitatNoms; i++){ //Crear inputs

        let inputCreate = document.createElement('input') //Para crear elements
            inputCreate.type = 'text'
            inputCreate.className = 'names'
            inputCreate.placeholder = 'Escriu el nom'
            
        let br = document.createElement('br')

        imprimirDiv.appendChild(inputCreate)   
        imprimirDiv.appendChild(br)
    }
    imprimirDiv.innerHTML += '<button type:"button" onclick="capturarNoms()">Capturar noms</button>'
}

//2. Funció de "Capturar noms" (sense paràmtres i sense return)
function capturarNoms() {
    
    let arrNoms = document.querySelectorAll('.names') //Inputs de l'usuari
    
    for (let i = 0; i < arrNoms.length; i++){
        //console.log(arrNoms[i].value)
        let nomsDef = arrNoms[i].value

        if (nomsDef.charAt(0).toUpperCase() == 'A'){ //Només els que comencen amb la lletra A
            //console.log(nomsDef)
            ArrayNoms.push(nomsDef)
        }
    }

    imprimir() //Funció 3 (Line 52)
}

//3. Funció per poder imprimir els noms més bonics (sense paràmetres i sense return)
function imprimir(){
    resultDiv.innerHTML = `Els noms més bonics són: ${ArrayNoms.join(', ')}`
}